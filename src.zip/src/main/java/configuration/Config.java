package configuration;

public class Config {
	
	public static final String API_KEY = "?key=3c99779a7b9540ed927ae33a304694b8";
    public static final String API_URL = "https://api.rawg.io/api/games";
    public static final String API_SEARCH = "&search=";
    public static final String API_PAGE_SIZE = "&page_size=30";
    public static final String API_PAGE = "&page=";

}
