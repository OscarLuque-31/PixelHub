package dao;

import models.JuegoNuevo;

public interface JuegoNuevoDao extends CommonDao<JuegoNuevo> {
}
