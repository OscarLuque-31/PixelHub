package dao;

import models.JuegosBiblioteca;

public interface JuegosBibliotecaDao extends CommonDao<JuegosBiblioteca> {
}
