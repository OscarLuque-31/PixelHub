package dao;

import models.Usuario;

public interface UsuarioDao extends CommonDao<Usuario> {
    // Métodos adicionales si son necesarios
}
