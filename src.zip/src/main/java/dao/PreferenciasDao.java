package dao;

import models.Preferencias;

public interface PreferenciasDao extends CommonDao<Preferencias> {
}
