package dao;

import models.Capturas;

public interface CapturasDao extends CommonDao<Capturas> {
}
