package dao;

import models.Plataformas;

public interface PlataformasDao extends CommonDao<Plataformas> {
}
