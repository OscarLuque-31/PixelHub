package controllers;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.Game;
import utils.APIUtils;
import utils.NavigationUtils;
import utils.UtilsViews;

public class BuscarJuegosController implements Initializable {

	@FXML
	private ImageView imgLupa;

	@FXML
	private TextField textFieldBusqueda;

	@FXML
	private ComboBox<?> comboBoxOrdenar;

	@FXML
	private ComboBox<?> comboBoxPlataforma;

	@FXML
	private ComboBox<?> comboBoxGenero;
	
	@FXML
	private ScrollPane scrollPane;

	@FXML
	private VBox contenedorJuegos;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Inicializar imágenes
		initializeImagesBar();
		// Efectos de hover
		hoverEffect();
		//Obtener y cargar los juegos
		showGames();
	}

	/**
	 * Método que recopila todos los hoverEffect
	 */
	public void hoverEffect() {
		// UtilsViews.hoverEffectButton(btnMinimizar, "#2a3b47", "#192229");
		// UtilsViews.hoverEffectButton(btnMaximizar, "#2a3b47", "#192229");
		// UtilsViews.hoverEffectButton(btnCerrar, "#c63637", "#192229");
		// UtilsViews.hoverEffectButton(btnBiblioteca, "#415A6C", "#212E36");
		// UtilsViews.hoverEffectButton(btnBuscarJuegos, "#415A6C", "#212E36");
		// UtilsViews.hoverEffectButton(btnCerrarSesion, "#415A6C", "#212E36");
		// UtilsViews.hoverEffectButton(btnRecomendaciones, "#415A6C", "#212E36");
	}

	/**
	 * Método que inicializa las imagenes
	 */
	public void initializeImagesBar() {
		imgLupa.setImage(new Image(getClass().getResourceAsStream("/images/lupa.png")));
	}

	/**
	 * Método que obtiene los juegos de la API y los muestra
	 */
	private void showGames() {
		scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
		scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

		try {
			List<Game> listaJuegos = APIUtils.getGames();
			contenedorJuegos.getChildren().clear();

				HBox filaActual = new HBox();
				filaActual.setSpacing(20);
				filaActual.setAlignment(Pos.CENTER); 

				int contador = 0;
				for (Game juego:listaJuegos) {
					VBox bloqueJuego = crearBloqueVideojuego(juego);
					bloqueJuego.setMaxWidth(Double.MAX_VALUE);
					filaActual.getChildren().add(bloqueJuego);
					contador++;

					if (contador % 3 == 0) {
						contenedorJuegos.setSpacing(20);
						contenedorJuegos.setAlignment(Pos.CENTER); 
						contenedorJuegos.getChildren().add(filaActual);

						filaActual = new HBox();
						filaActual.setSpacing(20);
						filaActual.setAlignment(Pos.CENTER); 
					}
				}
				if (!filaActual.getChildren().isEmpty()) {
					contenedorJuegos.getChildren().add(filaActual);
				} 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private VBox crearBloqueVideojuego(Game juego) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/GameItemCuadricula.fxml"));
			VBox gameItem = loader.load();

			// Obtener el controlador del FXML
			GameItemCuadriculaController controller = loader.getController();
			controller.setGameData(juego);
			controller.setGamesController(this);

			return gameItem;
		} catch (Exception e) {
			e.printStackTrace();
			return new VBox(new Label("Error cargando juego"));
		}
	}

	private HBox crearFilaVideojuego(Game juego) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/GameItemLista.fxml"));
			HBox gameItem = loader.load();

			GameItemListaController controller = loader.getController();
			controller.setGameData(juego);

			return gameItem;
		} catch (Exception e) {
			e.printStackTrace();
			return new HBox(new Label("Error cargando juego"));
		}
	}
	
	public void mostrarDetallesJuego(Game game) {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/GameDetails.fxml"));
	        HBox gameDetails = loader.load();

	        // Obtener el controlador del detalle
	        GameDetailsController controller = loader.getController();
	        controller.setGameDetails(game);

	        // Reemplazar el contenido del contenedor principal con la nueva vista
	        contenedorJuegos.getChildren().clear();
	        contenedorJuegos.getChildren().add(gameDetails);

	    } catch (Exception e) {
	        e.printStackTrace();
	        contenedorJuegos.getChildren().add(new Label("Error al cargar los detalles del juego."));
	    }
	}
}
