package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

public class RecomendacionesJuegosController {

    @FXML
    private ImageView imgLupa;

    @FXML
    private TextField textFieldBusqueda;

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private VBox contenedorJuegos;

}
